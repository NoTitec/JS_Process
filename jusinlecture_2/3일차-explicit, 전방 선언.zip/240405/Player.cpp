#include "stdafx.h"
#include "Player.h"


CPlayer::CPlayer()
{
	//m_pMonster = new CMonster;
}


CPlayer::~CPlayer()
{
}
