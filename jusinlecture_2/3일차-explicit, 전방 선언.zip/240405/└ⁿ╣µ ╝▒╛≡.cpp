#include "stdafx.h"
#include "Monster.h"

int main()
{
	CMonster		Monster;

	Monster.Draw();

	return 0;
}